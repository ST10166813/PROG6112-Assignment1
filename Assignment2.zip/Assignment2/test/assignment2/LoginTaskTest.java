/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package assignment2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoginTaskTest {
    
     private LoginTask task;

    @Before
    public void setUp() {
        task = new LoginTask();
    }

    @Test
    public void testAddTask() {
        task.addTask("Task 1", "Time 1");
        assertEquals(1, task.getTaskCount());
    }

    @Test
    public void testViewTasks() {
        taskManager.addTask("Task 1", "Time 1");
        taskManager.addTask("Task 2", "Time 2");

    }

    @Test
    public void testCompleteTask() {
        taskManager.addTask("Task 1", "Description 1");
        taskManager.completeTask(0);
        assertTrue(taskManager.getTasks()[0].isComplete());
    }
}
