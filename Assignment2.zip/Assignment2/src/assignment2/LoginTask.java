/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;


public class LoginTask {
    public static final int MAX_TASKS = 100;

    public Task[] getTasks() {
        return tasks;
    }
    private Task[] tasks;
    private int taskCount;

    public int getTaskCount() {
        return taskCount;
    }

    public LoginTask() {
        tasks = new Task[MAX_TASKS];
        taskCount = 0;
    }

    public void addTask(String name, String time) {
        if (taskCount < MAX_TASKS) {
            tasks[taskCount] = new Task(name, time);
            taskCount++;
        } else {
            System.out.println("Task limit reached. Cannot add more tasks.");
        }
    }

    public void viewTasks() {
        System.out.println("Task List:");
        for (int i = 0; i < taskCount; i++) {
            Task task = tasks[i];
            String status = task.isComplete() ? "Complete" : "Incomplete";
            System.out.println("Task #" + (i + 1) + ": " + task.getTask() + " - " + status);
        }
    }

    public void completeTask(int taskIndex) {
        if (taskIndex >= 0 && taskIndex < taskCount) {
            tasks[taskIndex].markComplete();
            System.out.println("Task #" + (taskIndex + 1) + " marked as complete.");
        } else {
            System.out.println("Invalid task index.");
        }
    }}
