/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment2;


import java.util.Scanner;

class Task {
   final  private String Task;
   final  private String TaskTime;
    private boolean isComplete;
 
      public Task(String Task, String TaskTime) {
         this.Task = Task;
         this.TaskTime = TaskTime;
         this.isComplete = false;
    }

    public String getTask() {
        return Task;
    }

    public String getTaskTime() {
        return TaskTime;
    }


    public boolean isComplete() {
         return isComplete;
    }

    public void markComplete() {
         isComplete = true;
    }
}
public class Assignment2 {
    
         public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       LoginTask   tasktracker = new LoginTask ();

         while (true) {
            System.out.println("\nTask Tracker");
            System.out.println("1. Add Task");
            System.out.println("2. Mark task that are Complete");
            System.out.println("3. All Tasks");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                
                 case 1: addTask(scanner,tasktracker);break;
                    
                 case 2: MarkTask(scanner,tasktracker); break;
                    
                 case 3: tasktracker.viewTasks();break;
                 
                 case 4:
                    System.out.println("Goodbye!");
                     scanner.close();
                     System.exit(0); break;
                     
                 default:  System.out.println("Invalid choice. Please try again.");
                 
            }
         }
    }
         
       public static void addTask(Scanner scanner, LoginTask tasktracker) {
        System.out.print("Enter Task Name/Description: ");
        String name = scanner.nextLine();

        System.out.print("Enter Start Time : ");
        String time = scanner.nextLine();

        tasktracker.addTask(name, time);
    }
         
      public static void MarkTask(Scanner scanner, LoginTask tasktracker) {
        System.out.print("Enter Task Index to Mark as Complete: ");
        int taskIndex = scanner.nextInt() - 1;
        tasktracker.completeTask(taskIndex);
    }
}
