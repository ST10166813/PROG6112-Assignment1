/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    private static ArrayList<Student> students = new ArrayList<>();

    private String studentID;
    private String studentName;
    private String studentEmail;
    private String course;
    private int studentAge;

    public static ArrayList<Student> getStudents() {
        return students;
    }

    public static void setStudents(ArrayList<Student> students) {
        Student.students = students;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public void setStudentAge(int studentAge) {
        this.studentAge = studentAge;
    }

    public Student(String studentID, String studentName, String studentEmail, String course, int studentAge) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.studentEmail = studentEmail;
        this.course = course;
        this.studentAge = studentAge;
    }

    public void displayInfo() {
        System.out.println("-------------------------------------");
        System.out.println("Student ID: " + studentID);
        System.out.println("Student Name: " + studentName);
        System.out.println("Student Age: " + studentAge);
        System.out.println("Student Email: " + studentEmail);
        System.out.println("Student Course: " + course);
        System.out.println("-------------------------------------");
    }

    public static boolean isValidAge(int age) {
        return age >= 16;
    }

    public void saveStudent() {
        Scanner kb = new Scanner(System.in);
        System.out.println("CAPTURE A NEW STUDENT\n" + "******************************************");
        System.out.print("Enter the student ID: ");
        String studentID = kb.nextLine();

        System.out.print("Enter the student name: ");
        String name = kb.nextLine();

        int age;
        do {
            System.out.print("Enter student age: ");
            age = kb.nextInt();
            if (!Student.isValidAge(age)) {
                System.out.println("You have entered an incorrect student age!!!");
                System.out.println("Please re-enter the student age>>");
            }
        } while (!Student.isValidAge(age));

        kb.nextLine(); // Consume newline character

        System.out.print("Enter the student email: ");
        String email = kb.nextLine();

        System.out.print("Enter the student course: ");
        String course = kb.nextLine();

        students.add(new Student(studentID, name, email, course, age));

        System.out.println("\nStudent details have been successfully saved.\n");
    }

    public void SearchStudent() {
        Scanner kb = new Scanner(System.in);
        System.out.print("\nEnter student ID to search:\n ");
        String searchId = kb.nextLine();
        boolean found = false;

        for (Student student : students) {
            if (student.getStudentID().equals(searchId)) {
                System.out.println("Student found:");
                student.displayInfo();
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student with Student Id: " + searchId + " was not found!\n");
        }
    }

    public static void DeleteStudent() {
        Scanner kb = new Scanner(System.in);
        System.out.print("\nEnter student ID to delete: ");
        String deleteId = kb.nextLine();
        boolean found = false;

        for (Student student : students) {
            if (student.getStudentID().equals(deleteId)) {
                System.out.print("Are you sure you want to delete this student? (yes/no): ");
                String firm = kb.nextLine().trim();
                if (firm.equalsIgnoreCase("yes")) {
                    students.remove(student);
                    System.out.println("Student deleted successfully.\n");
                }
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found.");
        }
    }

    public void StudentReport() {
        for (Student student : students) {
            System.out.println("Student" +
                    "\n-----------------------------------------------");
            System.out.println("Student ID: " + student.getStudentID());
            System.out.println("Student Name: " + student.getStudentName());
            System.out.println("Student Age: " + student.getStudentAge());
            System.out.println("Student Email: " + student.getStudentEmail());
            System.out.println("Student Course: " + student.getCourse());
            System.out.println("\n-----------------------------------------------");
            System.out.println();
        }
    }

    public void ExitStudentApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}
