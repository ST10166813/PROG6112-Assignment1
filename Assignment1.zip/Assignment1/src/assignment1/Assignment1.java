/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package assignment1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Assignment1 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner kb = new Scanner(System.in);

        // Display the initial application header
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("**********************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit");

        int choice;
        while (true) {
            try {
                // Read the user's choice from input
                choice = kb.nextInt();
            } catch (InputMismatchException e) {
                // Handle the case where the user enters a non-integer value
                break;
            }

            switch (choice) {
                case 1:
                    // Call the displayMenu method when the user chooses option 1
                    displayMenu(kb);
                    break;
                default:
                    // Exit the application if the user chooses any other option
                    System.out.println("Exiting the application.");
                    kb.close();
                    System.exit(0);
            }
        }
    }

    public static void displayMenu(Scanner scanner) {
        // Declare variables to store student data
        String STid, STName, STEmail, STCourse;
        int STAge;

        // Initialize student data with default values
        STName = " ";
        STid = " ";
        STEmail = " ";
        STCourse = " ";
        STAge = 1;

        // Create a Student object with the default values
        Student student = new Student(STid, STName, STEmail, STCourse, STAge);

        while (true) {
            // Display the menu options to the user
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new student");
            System.out.println("(2) Search for a student");
            System.out.println("(3) Delete a student");
            System.out.println("(4) Print student report");
            System.out.println("(5) Exit Application\n");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    // Call the saveStudent method to capture a new student's data
                    student.saveStudent();
                    break;
                case 2:
                    // Call the SearchStudent method to search for a student
                    student.SearchStudent();
                    break;
                case 3:
                    // Call the DeleteStudent method to delete a student
                    student.DeleteStudent( );
                    break;
                case 4:
                    // Call the StudentReport method to print a student report
                    student.StudentReport();
                    break;
                case 5:
                
                    student.ExitStudentApplication();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
         }
    }  
}
