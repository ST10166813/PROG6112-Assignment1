/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

package assignment1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class StudentTest {
    
    private Student student;

    @Before
    
    public void setUp() {

        // Initialize a Student object for testing
        student = new Student("S12345", "John Doe", "john@example.com", "Math", 20);
    }

   

    @Test

public void testSaveStudent() {

    // Create an ArrayList to simulate the students list
    ArrayList<Student> studentsList = new ArrayList<>();
    // Set the students list for the Student class
    Student.setStudents(studentsList);
    // Redirect System.out to capture output for testing
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

 

    // Mock user input to provide student details

    ByteArrayInputStream inContent = new ByteArrayInputStream(

        "S12345\nJohn Doe\n20\njohn@example.com\nMath\n".getBytes()

    );

    System.setIn(inContent);

 

    // Call the saveStudent method

    student.saveStudent();

 

    // Restore System.in and System.out

    System.setIn(System.in);

    System.setOut(System.out);

 

    // Check if the student has been added to the list

    assertEquals(1, studentsList.size());

 

    // Check if the added student's details match

    Student addedStudent = studentsList.get(0);

    assertEquals("S12345", addedStudent.getStudentID());

    assertEquals("John Doe", addedStudent.getStudentName());

    assertEquals("john@example.com", addedStudent.getStudentEmail());

    assertEquals("Math", addedStudent.getCourse());

    assertEquals(20, addedStudent.getStudentAge());

}

 

 

    @Test

    public void testIsValidAge() {
        
        assertTrue(Student.isValidAge(16));
        assertTrue(Student.isValidAge(17));
        assertTrue(Student.isValidAge(18));
        assertTrue(Student.isValidAge(19));
        assertTrue(Student.isValidAge(20));
        assertFalse(Student.isValidAge(15));
        assertFalse(Student.isValidAge(10));

    }
    
    @Test
    public void testIsValidAgeInvalid() {
        assertFalse(Student.isValidAge(15));
    }

@Test
public void testSearchStudent() {
    
    // Assuming there is a list of students in the students ArrayList
    Student.setStudents(new ArrayList<>());
    Student.getStudents().add(student);
    // Redirect System.out to capture output for testing
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));
    // Mock user input to provide student ID
    ByteArrayInputStream inContent = new ByteArrayInputStream("S12345\n".getBytes());
    System.setIn(inContent);
    // Call the SearchStudent method
    student.SearchStudent();
    // Restore System.in and System.out
    System.setIn(System.in);
    System.setOut(System.out);
    // Verify the output
    assertTrue(outContent.toString().contains("Student found:"));
    assertTrue(outContent.toString().contains("Student ID: S12345"));

}

@Test
public void testSearchStudentNotFound() {

    // Redirect System.out to capture output for testing
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));
    // Mock user input to provide student ID for a non-existing student
    ByteArrayInputStream inContent = new ByteArrayInputStream("S67890\n".getBytes());
    System.setIn(inContent);
    // Call the SearchStudent method
    student.SearchStudent();
    // Restore System.in and System.out
    System.setIn(System.in);
    System.setOut(System.out);
    // Verify the output
    assertTrue(outContent.toString().contains("Student with Student Id: S67890 was not found!"));

}


}

 


